# SMART — AI assistant starter

A single React web app that can also be packaged as an Android app with Capacitor.

## What is included
- Chat interface for SMART
- Backend proxy for OpenAI Responses API (keeps your API key off the phone/browser)
- Speech-to-text using the browser's Web Speech API where supported
- Spoken replies using the device/browser's built-in speech synthesis
- Local voice-sample recorder. It stays on the device and can be downloaded by the user.

## Important limitations
This is a runnable starter project, not a deployed public service. You must configure API keys,
install dependencies, and build/sign the Android app. The assistant can only do tasks supported
by its connected tools and permissions; it cannot literally do everything or control every app.

The "my own voice" feature is not yet voice cloning. A recording alone does not create a
voice model. To speak in your own voice, choose a reputable voice-cloning provider, review
its consent and data-retention terms, create a voice model using your own recording, and
connect its API on the server. Never upload another person's voice without their explicit
permission. Do not put provider/API keys in the frontend.

## Requirements
- Node.js 20+
- An OpenAI API key
- Android Studio only if you want to build/install the Android package

## Run locally

### 1. Start the backend
```bash
cd server
cp .env.example .env
# Add your OPENAI_API_KEY to .env
npm install
npm run dev
```
Backend runs at http://localhost:8787.

### 2. Start the web app
In another terminal:
```bash
cd client
npm install
npm run dev
```
Open the local Vite URL shown in the terminal. The web app expects the backend at
http://localhost:8787 by default.

## Build Android
```bash
cd client
npm run build
npx cap add android
npx cap sync android
npx cap open android
```
Build an APK/AAB from Android Studio. For a real Android release, configure HTTPS backend
URL in `client/.env` as `VITE_API_BASE_URL=https://your-domain.example`.

## Voice features
- Tap **Listen** to dictate text. Browser support varies; Chrome generally has the best support.
- Tap **Speak** to read the assistant's last reply using an installed device voice.
- Tap **Record my voice** to record a sample locally, then download it. This does not upload it
  or create a clone.
- For actual voice cloning, implement a server-side provider adapter in `server/src/index.js`
  after choosing a provider and obtaining informed consent. Keep the provider key server-side.

## Production checklist
- Deploy the backend behind HTTPS.
- Add authentication and per-user rate limits.
- Store secrets in hosting environment variables, never in Git or frontend code.
- Add privacy policy, retention/deletion controls, abuse protections, and monitoring.
- Configure CORS to your real website/app origins.
- Test microphone permissions and speech support on target Android devices.
