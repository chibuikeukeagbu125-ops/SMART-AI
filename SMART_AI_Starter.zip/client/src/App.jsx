import React, { useEffect, useRef, useState } from 'react';
import { Bot, Mic, MicOff, Send, Volume2, VolumeX, Download, AudioLines, Globe, ShieldCheck } from 'lucide-react';

const API = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8787';

export default function App() {
  const [messages, setMessages] = useState([
    { role: 'assistant', content: "Hello! I'm SMART, your AI assistant. Ask me anything, or use the microphone to dictate your message." }
  ]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const [listening, setListening] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const [recording, setRecording] = useState(false);
  const [sampleUrl, setSampleUrl] = useState('');
  const [error, setError] = useState('');
  const recognitionRef = useRef(null);
  const recorderRef = useRef(null);
  const chunksRef = useRef([]);
  const bottomRef = useRef(null);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages, busy]);

  function startListening() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setError('Speech recognition is not supported in this browser. Try Chrome on Android or type your message.');
      return;
    }
    setError('');
    const recognition = new SpeechRecognition();
    recognition.lang = navigator.language || 'en-US';
    recognition.interimResults = false;
    recognition.onresult = (event) => {
      const transcript = event.results?.[0]?.[0]?.transcript || '';
      setInput(v => v ? `${v} ${transcript}` : transcript);
      setListening(false);
    };
    recognition.onerror = () => { setListening(false); setError('Microphone input failed. Check browser microphone permission.'); };
    recognition.onend = () => setListening(false);
    recognitionRef.current = recognition;
    setListening(true);
    recognition.start();
  }

  function stopListening() {
    recognitionRef.current?.stop();
    setListening(false);
  }

  function speakLast() {
    const last = [...messages].reverse().find(m => m.role === 'assistant');
    if (!last || !('speechSynthesis' in window)) {
      setError('Spoken replies are not supported on this device/browser.');
      return;
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(last.content);
    utterance.onstart = () => setSpeaking(true);
    utterance.onend = () => setSpeaking(false);
    utterance.onerror = () => setSpeaking(false);
    window.speechSynthesis.speak(utterance);
  }

  function stopSpeaking() {
    window.speechSynthesis?.cancel();
    setSpeaking(false);
  }

  async function sendMessage(e) {
    e?.preventDefault();
    const text = input.trim();
    if (!text || busy) return;
    setError('');
    const next = [...messages, { role: 'user', content: text }];
    setMessages(next);
    setInput('');
    setBusy(true);
    try {
      const response = await fetch(`${API}/api/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: next.slice(-20) })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'The assistant could not respond.');
      setMessages(m => [...m, { role: 'assistant', content: data.reply }]);
    } catch (err) {
      setError(`${err.message} Make sure the SMART backend is running and configured.`);
    } finally {
      setBusy(false);
    }
  }

  async function startVoiceSample() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      chunksRef.current = [];
      const recorder = new MediaRecorder(stream);
      recorderRef.current = recorder;
      recorder.ondataavailable = e => { if (e.data.size) chunksRef.current.push(e.data); };
      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: recorder.mimeType || 'audio/webm' });
        if (sampleUrl) URL.revokeObjectURL(sampleUrl);
        setSampleUrl(URL.createObjectURL(blob));
        stream.getTracks().forEach(t => t.stop());
      };
      recorder.start();
      setRecording(true);
      setError('');
    } catch {
      setError('Could not access the microphone. Allow microphone permission and use HTTPS (or localhost).');
    }
  }

  function stopVoiceSample() {
    recorderRef.current?.stop();
    setRecording(false);
  }

  function downloadSample() {
    if (!sampleUrl) return;
    const a = document.createElement('a');
    a.href = sampleUrl;
    a.download = 'smart-my-voice-sample.webm';
    a.click();
  }

  return <div className="shell">
    <header className="topbar">
      <div className="brand"><div className="brandIcon"><Bot size={25}/></div><div><b>SMART</b><small>PERSONAL AI ASSISTANT</small></div></div>
      <div className="online"><span/> READY</div>
    </header>
    <main className="layout">
      <section className="hero">
        <div className="orb"><AudioLines size={38}/></div>
        <p className="eyebrow">YOUR WORLD, WITH A SMARTER ASSISTANT</p>
        <h1>What can I help<br/><em>you do today?</em></h1>
        <p className="sub">Ask a question, explore an idea, or tell SMART what you need.</p>
      </section>
      <section className="chatPanel">
        <div className="chatHead"><div><b><span className="pulse"/> SMART chat</b><small>AI assistant</small></div><div className="headActions">
          <button className="iconBtn" onClick={speaking ? stopSpeaking : speakLast} title={speaking ? 'Stop speaking' : 'Speak last reply'}>{speaking ? <VolumeX/> : <Volume2/>}</button>
        </div></div>
        <div className="messages">
          {messages.map((m,i)=><div key={i} className={`message ${m.role}`}><div className="avatar">{m.role === 'assistant' ? <Bot size={17}/> : 'YOU'}</div><div className="bubble"><div className="role">{m.role === 'assistant' ? 'SMART' : 'YOU'}</div>{m.content}</div></div>)}
          {busy && <div className="message assistant"><div className="avatar"><Bot size={17}/></div><div className="bubble"><div className="role">SMART</div><span className="dots">Thinking<span>.</span><span>.</span><span>.</span></span></div></div>}
          <div ref={bottomRef}/>
        </div>
        {error && <div className="error">{error}</div>}
        <form className="composer" onSubmit={sendMessage}>
          <button type="button" className={`micBtn ${listening?'active':''}`} onClick={listening ? stopListening : startListening} title="Dictate message">{listening ? <MicOff/> : <Mic/>}</button>
          <input value={input} onChange={e=>setInput(e.target.value)} placeholder={listening ? 'Listening… speak now' : 'Message SMART…'} />
          <button className="sendBtn" disabled={busy || !input.trim()} aria-label="Send"><Send size={19}/></button>
        </form>
        <p className="hint">SMART can make mistakes. Check important information.</p>
      </section>
      <section className="voicePanel">
        <div className="sectionTitle"><div className="miniIcon"><Mic size={18}/></div><div><b>Your voice</b><small>Personal voice setup</small></div></div>
        <p className="voiceText">Record a sample of your own voice. This starter keeps the recording on your device; it does not upload it or clone your voice.</p>
        <div className="voiceButtons">
          <button className="secondary" onClick={recording ? stopVoiceSample : startVoiceSample}>{recording ? <><MicOff size={17}/> Stop recording</> : <><Mic size={17}/> Record my voice</>}</button>
          <button className="secondary" disabled={!sampleUrl} onClick={downloadSample}><Download size={17}/> Download sample</button>
        </div>
        {recording && <div className="recording"><span/> Recording — speak naturally for a clear sample.</div>}
        {sampleUrl && <div className="saved"><ShieldCheck size={16}/> Voice sample recorded locally and ready to download.</div>}
        <div className="notice"><ShieldCheck size={17}/><span><b>Privacy first</b><br/>Your recording stays in this browser unless you choose to download it. Actual voice cloning requires a separate provider and your explicit consent.</span></div>
      </section>
    </main>
    <footer><Globe size={14}/> SMART • Web + Android starter <span>Built to grow with you</span></footer>
  </div>;
}
