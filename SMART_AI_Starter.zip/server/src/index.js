import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';

dotenv.config();
const app = express();
const port = Number(process.env.PORT || 8787);

app.use(cors({ origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173' }));
app.use(express.json({ limit: '1mb' }));

app.get('/api/health', (_req, res) => res.json({ ok: true, name: 'SMART' }));

app.post('/api/chat', async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({ error: 'SMART backend is missing OPENAI_API_KEY. Add it to server/.env.' });
    }
    const messages = Array.isArray(req.body?.messages) ? req.body.messages : [];
    const safeMessages = messages
      .filter(m => ['user', 'assistant'].includes(m?.role) && typeof m?.content === 'string')
      .slice(-20);
    if (!safeMessages.length) return res.status(400).json({ error: 'Please send a message.' });

    const transcript = safeMessages.map(m => `${m.role === 'user' ? 'User' : 'SMART'}: ${m.content}`).join('\\n');
    const upstream = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || 'gpt-4.1-mini',
        instructions: 'You are SMART, a helpful, honest personal AI assistant. Be clear and practical. You cannot claim to have performed actions you have not performed. Explain when a task requires an external tool, permission, or human confirmation.',
        input: transcript
      })
    });
    const data = await upstream.json();
    if (!upstream.ok) {
      return res.status(upstream.status).json({ error: data?.error?.message || 'AI service request failed.' });
    }
    const reply = data.output_text || data.output?.flatMap(item => item.content || []).find(c => c.type === 'output_text')?.text;
    if (!reply) return res.status(502).json({ error: 'SMART received an empty response from the AI service.' });
    res.json({ reply });
  } catch (error) {
    console.error('SMART chat error:', error);
    res.status(500).json({ error: 'Unexpected server error.' });
  }
});

// Voice-cloning integration intentionally not enabled in this starter.
// Add a provider here only after reviewing its consent, security, and retention requirements.
// Keep provider credentials on the server. Never accept or clone another person's voice without permission.

app.listen(port, () => console.log(`SMART backend listening on http://localhost:${port}`));
